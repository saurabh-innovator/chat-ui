import React, { useEffect, useState } from "react";
import styled from "styled-components";

const Container = styled.div`
    height: 100vh;
    display: flex;
    flex-direction:column
`;

const Header = styled.div`
    height: 50px;
    background-color:#a5a595;
    color:white;
    display:flex;
    align-items:center;
    flex-direction:column;
    justify-content:space-between;
    padding: 0 20px;
`;

const ChatArea = styled.div`
flex:1;
overflow:scroll;
`;

const InputContainer = styled.div`
height: 50px;
background-color:yellow;
display:flex;
align-items:center;
justify-content:space-between;
padding: 0 20px;
`;

const Input = styled.input`
flex:1;
height:30px;
padding: 0 30px;
border-radius: 15px;
border:none;
outline:none;
`;

const SendButton = styled.button`
height: 30px;
border-radius: 15px;
border:none;
cursor:pointer;
width:80px;
`;

const ChatWindow = (props) => {

    const [messages, setMessages] = useState([]);

    useEffect(() => {
        console.log(props.data.messageList)
        setMessages(props.data.messageList);
        console.log(messages)
    }, [props.data.messageList]);

    const handleSendMessage = (event) => {
        event.preventDefault();
        const message = event.target.elements.message.value;
        setMessages([...messages, message]);
        event.target.elements.message.value = ''
    };

    return (
        <Container>
            <div>
                <Header></Header>
                <ChatArea>
                    {messages && messages.map((message) => (<div key={message.messageId}>{message.message}</div>))}
                </ChatArea>
                <form onSubmit={handleSendMessage}>
                    <InputContainer>
                        <Input type="text" name="message" placeholder="Type a message" />
                        <SendButton>Send</SendButton>
                    </InputContainer>
                </form>
            </div>
        </Container>
    )
}

export default ChatWindow;
