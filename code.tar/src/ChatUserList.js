import React, { useEffect, useState } from "react";
import styled from "styled-components";
import ChatWindow from './ChatWindow';

const Container = styled.div`
    height: 100vh;
    display: flex;
    // flex-direction:column
`;

const Header = styled.div`
    height: 50px;
    background-color:#a5a595;
    color:white;
    display:flex;
    align-items:center;
    flex-direction:column;
    justify-content:space-between;
    padding: 0 20px;
`;

const ChatUserList = () => {
    const [data, setData] = useState([]);
    const [chatData, setChatData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [filteredData, setFilteredData] = useState([]);
    const [filterValue, setFilterValue] = useState('');

    useEffect(() => {
        fetch('https://my-json-server.typicode.com/codebuds-fk/chat/chats')
            .then((resp) => resp.json())
            .then((json) => {
                setData(json);
                setLoading(false)
            })
            .catch((err) => {
                console.log(err);
            })
    }, [])

    useEffect(() => {
        const filtered = data.filter(item => item.title.includes(filterValue));
        setFilteredData(filtered);
    }, [data, filterValue]);

    const handleFilterChange = (event) => {
        setFilterValue(event.target.value);
    }

    const handleButtonClick = (item) => {
        setChatData(item);
    }

    return (
        <Container>
            <div className="ChatOverall">
                <Header>Filter by title/order Id</Header>
                <div>
                    <input type="text" value={filterValue} placeholder="Filter..." onChange={handleFilterChange} />
                </div>
                <div className="Chat">
                    {loading ? (
                        <p>Loading...</p>
                    ) : (filteredData && filteredData.map((item) => (
                        <div className="ChatView" key={item.id} onClick={() => handleButtonClick(item)}>
                            <h2>
                                {item.title}
                            </h2>
                            <p>
                                {item.orderId}
                            </p>
                        </div>
                    )))}
                </div>
            </div>

            <ChatWindow data={chatData} />
        </Container>
    )
}

export default ChatUserList;
