import './App.css';
import ChatUserList from './ChatUserList';

function App() {
  return (
    <div className='App'>
      <ChatUserList />
    </div>
  );
}

export default App;
